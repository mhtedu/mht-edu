#!/bin/bash
set -e
echo "================================"
echo "棉花糖教育平台 - 完整后端更新"
echo "================================"
BASE_DIR="/www/wwwroot/mht-edu"
cd "$BASE_DIR"

# 备份
BACKUP_DIR="$BASE_DIR/backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
[ -d "server/dist" ] && cp -r server/dist "$BACKUP_DIR/server_dist" 2>/dev/null || true
echo "✅ 备份完成: $BACKUP_DIR"

# 解压同步包
SYNC_PKG=$(ls -t mht-edu-sync-*.tar.gz 2>/dev/null | head -1)
if [ -n "$SYNC_PKG" ]; then
    echo "解压: $SYNC_PKG"
    tar -xzf "$SYNC_PKG"
    
    # 同步后端
    cp -r mht-edu-sync/server/dist/* server/dist/
    rm -rf mht-edu-sync
    echo "✅ 文件同步完成"
fi

# 重启服务
echo "重启服务..."
pm2 restart mht-edu-server
sleep 3

# 验证
echo "验证服务..."
curl -s "http://localhost:3002/api/hello" && echo "" || echo "API响应失败"

# 检查路由
echo ""
echo "检查活动路由..."
pm2 logs mht-edu-server --lines 50 --nostream 2>/dev/null | grep "activities" | tail -5

echo ""
echo "================================"
echo "✅ 更新完成！"
echo "================================"
