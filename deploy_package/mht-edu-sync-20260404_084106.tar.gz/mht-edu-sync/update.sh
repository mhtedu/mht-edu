#!/bin/bash
set -e
echo "================================"
echo "棉花糖教育平台 - 后端端口修复"
echo "================================"
BASE_DIR="/www/wwwroot/mht-edu"
cd "$BASE_DIR"

# 备份
BACKUP_DIR="$BASE_DIR/backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
[ -d "server/dist" ] && cp -r server/dist "$BACKUP_DIR/server_dist" 2>/dev/null || true
echo "✅ 备份完成: $BACKUP_DIR"

# 解压同步包
SYNC_PKG=$(ls -t mht-edu-sync-*.tar.gz 2>/dev/null | head -1)
if [ -n "$SYNC_PKG" ]; then
    echo "解压: $SYNC_PKG"
    tar -xzf "$SYNC_PKG"
    
    # 同步后端
    cp -r mht-edu-sync/server/dist/* server/dist/
    rm -rf mht-edu-sync
    echo "✅ 文件同步完成"
fi

# 停止所有旧服务
echo "停止旧服务..."
pm2 stop mht-edu-server 2>/dev/null || true
pm2 stop mht-edu-api 2>/dev/null || true
pm2 delete mht-edu-server 2>/dev/null || true
pm2 delete mht-edu-api 2>/dev/null || true

# 等待端口释放
sleep 2

# 启动新服务
echo "启动服务..."
cd "$BASE_DIR/server"
pm2 start dist/src/main.js --name mht-edu-server
pm2 save

sleep 3

# 验证
if curl -s "http://localhost:3002/api/hello" | grep -q "Hello"; then
    echo "✅ 服务启动成功！端口: 3002"
else
    echo "❌ 服务启动失败，检查日志..."
    pm2 logs mht-edu-server --lines 10
fi
