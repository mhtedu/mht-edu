#!/bin/bash
set -e
echo "================================"
echo "棉花糖教育平台 - 一键更新"
echo "================================"
BASE_DIR="/www/wwwroot/mht-edu"
cd "$BASE_DIR"

# 备份
BACKUP_DIR="$BASE_DIR/backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"
[ -f "index.html" ] && cp index.html "$BACKUP_DIR/" 2>/dev/null || true
[ -d "js" ] && cp -r js "$BACKUP_DIR/" 2>/dev/null || true
[ -d "server/dist" ] && cp -r server/dist "$BACKUP_DIR/server_dist" 2>/dev/null || true
echo "✅ 备份完成: $BACKUP_DIR"

# 解压同步包（如果有）
SYNC_PKG=$(ls -t mht-edu-sync-*.tar.gz 2>/dev/null | head -1)
if [ -n "$SYNC_PKG" ]; then
    echo "解压: $SYNC_PKG"
    tar -xzf "$SYNC_PKG"
    
    # 同步前端（直接在顶层）
    [ -f "mht-edu-sync/index.html" ] && cp mht-edu-sync/index.html .
    [ -d "mht-edu-sync/js" ] && cp -r mht-edu-sync/js/* js/
    [ -d "mht-edu-sync/css" ] && cp -r mht-edu-sync/css/* css/
    [ -d "mht-edu-sync/admin" ] && cp -r mht-edu-sync/admin/* admin/
    [ -d "mht-edu-sync/dist-weapp" ] && cp -r mht-edu-sync/dist-weapp/* dist-weapp/
    [ -d "mht-edu-sync/server/dist" ] && cp -r mht-edu-sync/server/dist/* server/dist/
    [ -d "mht-edu-sync/server/src" ] && cp -r mht-edu-sync/server/src/* server/src/
    
    rm -rf mht-edu-sync
    echo "✅ 文件同步完成"
fi

# 重启服务
cd "$BASE_DIR/server"
pm2 restart mht-edu-server 2>/dev/null || pm2 start dist/src/main.js --name mht-edu-server
echo "✅ 服务重启完成"

echo ""
echo "✅ 更新完成！"
echo "H5: https://wx.dajiaopei.com/"
echo "管理后台: https://wx.dajiaopei.com/admin/"
