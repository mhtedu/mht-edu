export declare class TeacherModule {
}
