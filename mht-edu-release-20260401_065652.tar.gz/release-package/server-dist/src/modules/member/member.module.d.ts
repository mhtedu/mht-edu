export declare class MemberModule {
}
