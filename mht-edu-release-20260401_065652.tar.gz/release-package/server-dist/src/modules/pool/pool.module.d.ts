export declare class PoolModule {
}
