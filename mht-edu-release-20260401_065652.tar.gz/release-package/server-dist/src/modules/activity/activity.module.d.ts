export declare class ActivityModule {
}
