export declare class LessonModule {
}
