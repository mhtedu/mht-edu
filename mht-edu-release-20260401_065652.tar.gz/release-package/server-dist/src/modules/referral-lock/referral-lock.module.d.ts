export declare class ReferralLockModule {
}
