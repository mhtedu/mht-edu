export declare class EliteClassModule {
}
