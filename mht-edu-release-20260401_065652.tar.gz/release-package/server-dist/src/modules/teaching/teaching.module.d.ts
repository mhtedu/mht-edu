export declare class TeachingModule {
}
