export declare class MembershipModule {
}
