export declare class OrgAssignModule {
}
