export declare class TeacherProfileModule {
}
