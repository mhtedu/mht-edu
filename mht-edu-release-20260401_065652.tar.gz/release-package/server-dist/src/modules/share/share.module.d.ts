export declare class ShareModule {
}
