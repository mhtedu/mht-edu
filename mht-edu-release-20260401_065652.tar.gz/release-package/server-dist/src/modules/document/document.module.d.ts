export declare class DocumentModule {
}
