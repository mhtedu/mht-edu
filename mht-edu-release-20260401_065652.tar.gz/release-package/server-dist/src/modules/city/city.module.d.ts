export declare class CityModule {
}
