export declare class DistributionModule {
}
