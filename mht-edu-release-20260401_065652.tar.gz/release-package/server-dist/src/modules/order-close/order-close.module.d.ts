export declare class OrderCloseModule {
}
