export declare class MessageModule {
}
