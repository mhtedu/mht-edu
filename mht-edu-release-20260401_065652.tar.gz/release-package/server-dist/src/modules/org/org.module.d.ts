export declare class OrgModule {
}
