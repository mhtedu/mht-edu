export declare class RobotModule {
}
