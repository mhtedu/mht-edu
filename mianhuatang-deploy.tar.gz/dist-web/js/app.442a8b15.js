import{g as pe,E as W,n as me,s as fe,b as v,d as U,o as b,_ as x,j as o,V as l,p as he,H as ge,f as ve,q as R,i as be,S as xe,v as we,w as ye,e as Ee,x as _e,X as Ce,y as je,z as Te,A as Be,B as p,D as u,F as Se,G as Q,J as Z,r as A,K as Fe,M as Pe,N as ke,O as Ne,P as Ae,Q as De,U as ee,W as h}from"./vendors.b2f0d69b.js";import{c as O,P as Oe,B as S,C as He,a as Re,b as D,d as Le,e as Ie,t as $,T as ze}from"./common.eb310ac8.js";(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))n(i);new MutationObserver(i=>{for(const a of i)if(a.type==="childList")for(const t of a.addedNodes)t.tagName==="LINK"&&t.rel==="modulepreload"&&n(t)}).observe(document,{childList:!0,subtree:!0});function r(i){const a={};return i.integrity&&(a.integrity=i.integrity),i.referrerPolicy&&(a.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?a.credentials="include":i.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function n(i){if(i.ep)return;i.ep=!0;const a=r(i);fetch(i.href,a)}})();var Ve=`
/* H5 端隐藏 TabBar 空图标（只隐藏没有 src 的图标） */
.weui-tabbar__icon:not([src]),
.weui-tabbar__icon[src=''] {
  display: none !important;
}

.weui-tabbar__item:has(.weui-tabbar__icon:not([src])) .weui-tabbar__label,
.weui-tabbar__item:has(.weui-tabbar__icon[src='']) .weui-tabbar__label {
  margin-top: 0 !important;
}

/* Vite 错误覆盖层无法选择文本的问题 */
vite-error-overlay {
  /* stylelint-disable-next-line property-no-vendor-prefix */
  -webkit-user-select: text !important;
}

vite-error-overlay::part(window) {
  max-width: 90vw;
  padding: 10px;
}

.taro_page {
  overflow: auto;
}

::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}

::-webkit-scrollbar-track {
  background: transparent;
}

::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.2);
  border-radius: 2px;
}

::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.3);
}

/* H5 导航栏页面自动添加顶部间距 */
body.h5-navbar-visible .taro_page {
  padding-top: 44px;
}

body.h5-navbar-visible .toaster[data-position^="top"] {
  top: 44px !important;
}

/* Sheet 组件在 H5 导航栏下的位置修正 */
body.h5-navbar-visible .sheet-content:not([data-side="bottom"]) {
    top: 44px !important;
}

/*
 * H5 端 rem 适配：与小程序 rpx 缩放一致
 * 375px 屏幕：1rem = 16px，小程序 32rpx = 16px
 */
html {
    font-size: 4vw !important;
}

/* H5 端组件默认样式修复 */
taro-view-core {
    display: block;
}

taro-text-core {
    display: inline;
}

taro-input-core {
    display: block;
    width: 100%;
}

taro-input-core input {
    width: 100%;
    background: transparent;
    border: none;
    outline: none;
}

taro-input-core.taro-otp-hidden-input input {
    color: transparent;
    caret-color: transparent;
    -webkit-text-fill-color: transparent;
}

/* 全局按钮样式重置 */
taro-button-core,
button {
    margin: 0 !important;
    padding: 0 !important;
    line-height: inherit;
    display: flex;
    align-items: center;
    justify-content: center;
}

taro-button-core::after,
button::after {
    border: none;
}

taro-textarea-core > textarea,
.taro-textarea,
textarea.taro-textarea {
    resize: none !important;
}
`,Me=`
/* PC 宽屏适配 - 基础布局 */
@media (min-width: 769px) {
  html {
    font-size: 15px !important;
  }

  body {
    background-color: #f3f4f6 !important;
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    min-height: 100vh !important;
  }
}
`,We=`
/* PC 宽屏适配 - 手机框样式（有 TabBar 页面） */
@media (min-width: 769px) {
  .taro-tabbar__container {
    width: 375px !important;
    max-width: 375px !important;
    height: calc(100vh - 40px) !important;
    max-height: 900px !important;
    background-color: #fff !important;
    transform: translateX(0) !important;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1) !important;
    border-radius: 20px !important;
    overflow: hidden !important;
    position: relative !important;
  }

  .taro-tabbar__panel {
    height: 100% !important;
    overflow: auto !important;
  }
}

/* PC 宽屏适配 - Toast 定位到手机框范围内 */
@media (min-width: 769px) {
  body .toaster {
    left: 50% !important;
    right: auto !important;
    width: 375px !important;
    max-width: 375px !important;
    transform: translateX(-50%) !important;
    box-sizing: border-box !important;
  }
}

/* PC 宽屏适配 - 手机框样式（无 TabBar 页面，通过 JS 添加 no-tabbar 类） */
@media (min-width: 769px) {
  body.no-tabbar #app {
    width: 375px !important;
    max-width: 375px !important;
    height: calc(100vh - 40px) !important;
    max-height: 900px !important;
    background-color: #fff !important;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1) !important;
    border-radius: 20px !important;
    overflow: hidden !important;
    position: relative !important;
    transform: translateX(0) !important;
  }

  body.no-tabbar #app .taro_router {
    height: 100% !important;
    overflow: auto !important;
  }
}
`;function Ue(){var s=document.createElement("style");s.innerHTML=Ve+Me+We,document.head.appendChild(s)}function $e(){var s=function(){var n=!!document.querySelector(".taro-tabbar__container");document.body.classList.toggle("no-tabbar",!n)};s();var e=new MutationObserver(s);e.observe(document.body,{childList:!0,subtree:!0})}function qe(){Ue(),$e()}function Xe(){var s=pe();if(s===W.WEAPP||s===W.TT)try{var e=me(),r=e.miniProgram.envVersion;console.log("[Debug] envVersion:",r),r!=="release"&&fe({enableDebug:!0})}catch(n){console.error("[Debug] 开启调试模式失败:",n)}}var Ye={visible:!1,title:"",bgColor:"#ffffff",textStyle:"black",navStyle:"default",transparent:"none",leftIcon:"none"},Ge=function(){var e,r=R();return(r==null||(e=r.config)===null||e===void 0?void 0:e.window)||{}},Je=function(){var e,r,n=(e=R())===null||e===void 0||(e=e.config)===null||e===void 0?void 0:e.tabBar;return new Set((n==null||(r=n.list)===null||r===void 0?void 0:r.map(function(i){return i.pagePath}))||[])},q=function(){var e,r=R();return(r==null||(e=r.config)===null||e===void 0||(e=e.pages)===null||e===void 0?void 0:e[0])||"pages/index/index"},P=function(e){return e.replace(/^\//,"")},Ke=function(e,r,n,i){if(!e)return"none";var a=P(e),t=P(i),g=a===t,c=r.has(a)||r.has("/".concat(a)),m=n>1;return c||g?"none":m?"back":"home"},Qe=function(){var e=v.useState(Ye),r=U(e,2),n=r[0],i=r[1],a=v.useState(0),t=U(a,2),g=t[0],c=t[1],m=v.useCallback(function(){var d=b.getCurrentPages();if(d.length===0){i(function(de){return x(x({},de),{},{visible:!1})});return}var f=d[d.length-1],z=(f==null?void 0:f.route)||"";if(z){var w=(f==null?void 0:f.config)||{},y=Ge(),T=Je(),le=q(),B=P(z),V=P(le),ue=B===V,ce=T.has(B)||T.has("/".concat(B)),M=T.size<=1&&d.length<=1&&(ue||ce);i({visible:!M,title:document.title||w.navigationBarTitleText||y.navigationBarTitleText||"",bgColor:w.navigationBarBackgroundColor||y.navigationBarBackgroundColor||"#ffffff",textStyle:w.navigationBarTextStyle||y.navigationBarTextStyle||"black",navStyle:w.navigationStyle||y.navigationStyle||"default",transparent:w.transparentTitle||y.transparentTitle||"none",leftIcon:M?"none":Ke(B,T,d.length,V)})}},[]);b.useDidShow(function(){m()}),b.usePageScroll(function(d){var f=d.scrollTop;n.transparent==="auto"&&c(Math.min(f/100,1))}),v.useEffect(function(){var d=null,f=new MutationObserver(function(){d&&clearTimeout(d),d=setTimeout(function(){m()},50)});return f.observe(document.head,{subtree:!0,childList:!0,characterData:!0}),m(),function(){f.disconnect(),d&&clearTimeout(d)}},[m]);var N=n.visible&&n.navStyle!=="custom";if(v.useEffect(function(){N?document.body.classList.add("h5-navbar-visible"):document.body.classList.remove("h5-navbar-visible")},[N]),!N)return o.jsx(o.Fragment,{});var I=n.textStyle==="white"?"#fff":"#333",ae=n.textStyle==="white"?"text-white":"text-gray-800",ie=function(){return n.transparent==="always"?{backgroundColor:"transparent"}:n.transparent==="auto"?{backgroundColor:n.bgColor,opacity:g}:{backgroundColor:n.bgColor}},oe=function(){return b.navigateBack()},se=function(){var f=q();b.reLaunch({url:"/".concat(f)})};return o.jsxs(o.Fragment,{children:[o.jsxs(l,{className:"fixed top-0 left-0 right-0 h-11 flex items-center justify-center z-1000",style:ie(),children:[n.leftIcon==="back"&&o.jsx(l,{className:"absolute left-2 top-1/2 -translate-y-1/2 p-1 flex items-center justify-center",onClick:oe,children:o.jsx(he,{size:24,color:I})}),n.leftIcon==="home"&&o.jsx(l,{className:"absolute left-2 top-1/2 -translate-y-1/2 p-1 flex items-center justify-center",onClick:se,children:o.jsx(ge,{size:22,color:I})}),o.jsx(ve,{className:"text-base font-medium max-w-3/5 truncate ".concat(ae),children:n.title})]}),o.jsx(l,{className:"h-11 shrink-0"})]})},Ze=function(e){var r=e.children;return o.jsxs(o.Fragment,{children:[o.jsx(Qe,{}),r]})},er=["className","children","orientation"],re=v.forwardRef(function(s,e){var r=s.className,n=s.children,i=s.orientation,a=i===void 0?"vertical":i,t=be(s,er),g=a==="horizontal"||a==="both",c=a==="vertical"||a==="both";return o.jsx(xe,x(x({ref:e,className:O("relative",r),scrollY:c,scrollX:g,style:{overflowX:g?"auto":"hidden",overflowY:c?"auto":"hidden"}},t),{},{children:n}))});re.displayName="ScrollArea";var rr={error:null,report:"",source:"",visible:!1,open:!1,timestamp:""},X="hsl(360, 100%, 45%)",Y=!1,k=rr,H=new Set,nr=function(){H.forEach(function(e){return e()})},tr=function(e){return H.add(e),function(){return H.delete(e)}},G=function(){return k},ne=function(e){k=e,nr()},ar=function(){var s=p(u().m(function e(r){var n,i,a,t,g;return u().w(function(c){for(;;)switch(c.p=c.n){case 0:if(typeof window!="undefined"){c.n=1;break}return c.a(2,!1);case 1:if(c.p=1,!((n=navigator.clipboard)!==null&&n!==void 0&&n.writeText)){c.n=3;break}return c.n=2,navigator.clipboard.writeText(r);case 2:return c.a(2,!0);case 3:c.n=5;break;case 4:c.p=4,t=c.v,console.warn("[H5ErrorBoundary] Clipboard API copy failed:",t);case 5:return c.p=5,i=document.createElement("textarea"),i.value=r,i.setAttribute("readonly","true"),i.style.position="fixed",i.style.opacity="0",document.body.appendChild(i),i.select(),a=document.execCommand("copy"),document.body.removeChild(i),c.a(2,a);case 6:return c.p=6,g=c.v,console.warn("[H5ErrorBoundary] Fallback copy failed:",g),c.a(2,!1)}},e,null,[[5,6],[1,4]])}));return function(r){return s.apply(this,arguments)}}(),ir=function(e){if(e instanceof Error)return e;if(typeof e=="string")return new Error(e);try{return new Error(JSON.stringify(e))}catch(r){return new Error(String(e))}},or=function(e){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n=["[H5 Runtime Error]","Time: ".concat(new Date().toISOString()),r.source?"Source: ".concat(r.source):"","Name: ".concat(e.name),"Message: ".concat(e.message),e.stack?`Stack:
`.concat(e.stack):"",r.componentStack?`Component Stack:
`.concat(r.componentStack):"",typeof navigator!="undefined"?"User Agent: ".concat(navigator.userAgent):""].filter(Boolean);return n.join(`

`)},J=function(e){k.visible&&ne(x(x({},k),{},{open:e}))},L=function(e){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};if(typeof window!="undefined"){var n=ir(e),i=or(n,r),a=new Date().toLocaleTimeString("zh-CN",{hour:"2-digit",minute:"2-digit",second:"2-digit"});ne({error:n,report:i,source:r.source||"runtime",timestamp:a,visible:!0,open:!1}),console.error("[H5ErrorOverlay] Showing error overlay:",n,r)}},sr=function(e){var r=e.error||new Error(e.message||"Unknown H5 runtime error");L(r,{source:"window.error"})},lr=function(e){L(e.reason,{source:"window.unhandledrejection"})},ur=function(){typeof window=="undefined"||Y||(Y=!0,window.addEventListener("error",sr),window.addEventListener("unhandledrejection",lr))},cr=function(){var e,r,n=v.useSyncExternalStore(tr,G,G);if(!n.visible)return null;var i=((e=n.error)===null||e===void 0?void 0:e.name)||"Error";return o.jsx(Oe,{children:o.jsxs(l,{className:"pointer-events-none fixed inset-0 z-[2147483646]",children:[o.jsx(l,{className:"pointer-events-auto fixed bottom-5 left-5",children:o.jsx(S,{variant:"outline",size:"icon",className:O("h-11 w-11 rounded-full shadow-md transition-transform"),style:{backgroundColor:"hsl(359, 100%, 97%)",borderColor:"hsl(359, 100%, 94%)",color:X},onClick:function(){return J(!n.open)},children:o.jsx(Ee,{size:22,color:X})})}),n.open&&o.jsx(l,{className:"pointer-events-none fixed inset-0 bg-white bg-opacity-15 supports-[backdrop-filter]:backdrop-blur-md",children:o.jsx(l,{className:"absolute inset-0 flex items-center justify-center px-4 py-4",children:o.jsx(l,{className:"w-full max-w-md",style:{width:"min(calc(100vw - 32px), var(--h5-phone-width, 390px))",height:"min(calc(100vh - 32px), 900px)"},children:o.jsx(He,{className:O("pointer-events-auto h-full rounded-2xl border border-border bg-background text-foreground shadow-2xl"),children:o.jsxs(l,{className:"relative flex h-full flex-col",children:[o.jsxs(Re,{className:"gap-2 p-4 pb-2",children:[o.jsxs(l,{className:"flex items-start justify-between gap-3",children:[o.jsxs(l,{className:"flex flex-wrap items-center gap-2",children:[o.jsx(D,{variant:"destructive",className:"border-none bg-red-500 px-3 py-1 text-xs font-medium text-white",children:"Runtime Error"}),o.jsx(D,{variant:"outline",className:"px-3 py-1 text-xs",children:n.source})]}),o.jsxs(l,{className:"flex shrink-0 items-center gap-1",children:[o.jsx(S,{variant:"ghost",size:"icon",className:"h-8 w-8 rounded-full",onClick:function(){return window.location.reload()},children:o.jsx(_e,{size:15,color:"inherit"})}),o.jsx(S,{variant:"ghost",size:"icon",className:"h-8 w-8 rounded-full",onClick:function(){return J(!1)},children:o.jsx(Ce,{size:17,color:"inherit"})})]})]}),o.jsxs(l,{className:"flex items-center justify-between gap-3",children:[o.jsx(Le,{className:"text-left text-lg",children:i}),o.jsxs(S,{variant:"outline",size:"sm",className:"shrink-0 rounded-lg",onClick:function(){var a=p(u().m(function g(){var c;return u().w(function(m){for(;;)switch(m.n){case 0:return m.n=1,ar(n.report);case 1:if(c=m.v,!c){m.n=2;break}return $.success("已复制错误信息",{description:"可发送给 Agent 进行自动修复",position:"top-center"}),m.a(2);case 2:$.warning("复制失败",{description:"请直接选中文本后手动复制。",position:"top-center"});case 3:return m.a(2)}},g)}));function t(){return a.apply(this,arguments)}return t}(),children:[o.jsx(je,{size:15,color:"inherit"}),o.jsx(l,{children:"复制错误"})]})]})]}),o.jsx(Ie,{className:"min-h-0 flex-1 overflow-hidden px-4 pb-4 pt-2",children:o.jsxs(l,{className:"flex h-full min-h-0 flex-col gap-2",children:[o.jsxs(l,{className:"flex flex-wrap items-center gap-x-4 gap-y-2 rounded-lg border border-border px-3 py-2 text-sm",children:[o.jsxs(l,{className:"flex items-center gap-2",children:[o.jsx(l,{className:"text-muted-foreground",children:"Error"}),o.jsx(l,{className:"font-medium text-foreground",children:((r=n.error)===null||r===void 0?void 0:r.name)||"Error"})]}),o.jsx(l,{className:"h-4 w-px bg-border"}),o.jsxs(l,{className:"flex items-center gap-2",children:[o.jsx(l,{className:"text-muted-foreground",children:"Source"}),o.jsx(l,{className:"font-medium text-foreground",children:n.source})]})]}),o.jsxs(l,{className:"min-h-0 flex flex-1 flex-col overflow-hidden rounded-xl border border-border bg-black text-white",children:[o.jsxs(l,{className:"flex items-center justify-between border-b border-white border-opacity-10 px-3 py-3",children:[o.jsx(l,{className:"text-xs font-medium uppercase tracking-wide text-zinc-400",children:"Full Report"}),o.jsx(D,{variant:"outline",className:"border-zinc-700 bg-transparent px-2 py-1 text-xs text-zinc-400",children:n.timestamp})]}),o.jsx(re,{className:"min-h-0 flex-1 w-full",orientation:"both",children:o.jsx(l,{className:"inline-block min-w-full whitespace-pre px-3 py-3 pb-8 font-mono text-xs leading-6 text-zinc-200",children:n.report})})]})]})})]})})})})})]})})},dr=function(s){function e(){var r;Te(this,e);for(var n=arguments.length,i=new Array(n),a=0;a<n;a++)i[a]=arguments[a];return r=Be(this,e,[].concat(i)),r.state={error:null},r}return we(e,s),ye(e,[{key:"componentDidUpdate",value:function(n){this.state.error&&n.children!==this.props.children&&this.setState({error:null})}},{key:"componentDidCatch",value:function(n,i){L(n,{source:"React Error Boundary",componentStack:i.componentStack||""})}},{key:"render",value:function(){return o.jsxs(o.Fragment,{children:[o.jsx(cr,{}),this.state.error?null:this.props.children]})}}],[{key:"getDerivedStateFromError",value:function(n){return{error:n}}}])}(v.Component),pr=function(e){var r=e.children;return o.jsx(dr,{children:r})},mr=function(e){var r=e.children;return ur(),b.useLaunch(function(){Xe(),qe()}),o.jsx(pr,{children:o.jsx(Ze,{children:r})})},fr=function(e){var r=e.children;return o.jsxs(Se,{defaultColor:"#000",defaultSize:24,children:[o.jsx(mr,{children:r}),o.jsx(ze,{})]})},_=Q.__taroAppConfig={router:{mode:"hash"},pages:["pages/index/index","pages/message/index","pages/orders/index","pages/profile/index","pages/publish/index","pages/teacher-detail/index","pages/order-detail/index","pages/membership/index","pages/distribution/index","pages/org-dashboard/index","pages/agent-dashboard/index","pages/admin/index"],window:{backgroundTextStyle:"light",navigationBarBackgroundColor:"#fff",navigationBarTitleText:"棉花糖教育",navigationBarTextStyle:"black"},tabBar:{color:"#999999",selectedColor:"#2563EB",backgroundColor:"#ffffff",borderStyle:"black",list:[{pagePath:"pages/index/index",text:"首页",iconPath:"./assets/tabbar/home.png",selectedIconPath:"./assets/tabbar/home-active.png"},{pagePath:"pages/message/index",text:"消息",iconPath:"./assets/tabbar/message-square.png",selectedIconPath:"./assets/tabbar/message-square-active.png"},{pagePath:"pages/orders/index",text:"订单",iconPath:"./assets/tabbar/clipboard-list.png",selectedIconPath:"./assets/tabbar/clipboard-list-active.png"},{pagePath:"pages/profile/index",text:"我的",iconPath:"./assets/tabbar/user.png",selectedIconPath:"./assets/tabbar/user-active.png"}]}},C=[],j=[];C[0]="/static/images/home.png";j[0]="/static/images/home-active.png";C[1]="/static/images/message-square.png";j[1]="/static/images/message-square-active.png";C[2]="/static/images/clipboard-list.png";j[2]="/static/images/clipboard-list-active.png";C[3]="/static/images/user.png";j[3]="/static/images/user-active.png";var K=_.tabBar.list;for(var E=0;E<K.length;E++){var F=K[E];F.iconPath&&(F.iconPath=C[E]),F.selectedIconPath&&(F.selectedIconPath=j[E])}_.routes=[Object.assign({path:"pages/index/index",load:function(){var s=p(u().m(function r(n,i){var a;return u().w(function(t){for(;;)switch(t.n){case 0:return t.n=1,h(()=>import("./index.966c920a.js"),["./index.966c920a.js","./vendors.b2f0d69b.js","../css/vendors.8886af03.css","./common.eb310ac8.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return a=t.v,t.a(2,[a,n,i])}},r)}));function e(r,n){return s.apply(this,arguments)}return e}()},{navigationBarTitleText:"首页"}),Object.assign({path:"pages/message/index",load:function(){var s=p(u().m(function r(n,i){var a;return u().w(function(t){for(;;)switch(t.n){case 0:return t.n=1,h(()=>import("./index.ce2ccde9.js"),["./index.ce2ccde9.js","./vendors.b2f0d69b.js","../css/vendors.8886af03.css","./common.eb310ac8.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return a=t.v,t.a(2,[a,n,i])}},r)}));function e(r,n){return s.apply(this,arguments)}return e}()},{navigationBarTitleText:"消息"}),Object.assign({path:"pages/orders/index",load:function(){var s=p(u().m(function r(n,i){var a;return u().w(function(t){for(;;)switch(t.n){case 0:return t.n=1,h(()=>import("./index.27e8dddb.js"),["./index.27e8dddb.js","./vendors.b2f0d69b.js","../css/vendors.8886af03.css","./common.eb310ac8.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return a=t.v,t.a(2,[a,n,i])}},r)}));function e(r,n){return s.apply(this,arguments)}return e}()},{navigationBarTitleText:"订单"}),Object.assign({path:"pages/profile/index",load:function(){var s=p(u().m(function r(n,i){var a;return u().w(function(t){for(;;)switch(t.n){case 0:return t.n=1,h(()=>import("./index.12d92543.js"),["./index.12d92543.js","./vendors.b2f0d69b.js","../css/vendors.8886af03.css","./common.eb310ac8.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return a=t.v,t.a(2,[a,n,i])}},r)}));function e(r,n){return s.apply(this,arguments)}return e}()},{navigationBarTitleText:"我的"}),Object.assign({path:"pages/publish/index",load:function(){var s=p(u().m(function r(n,i){var a;return u().w(function(t){for(;;)switch(t.n){case 0:return t.n=1,h(()=>import("./index.4db1514e.js"),["./index.4db1514e.js","./vendors.b2f0d69b.js","../css/vendors.8886af03.css","./common.eb310ac8.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return a=t.v,t.a(2,[a,n,i])}},r)}));function e(r,n){return s.apply(this,arguments)}return e}()},{navigationBarTitleText:"发布需求"}),Object.assign({path:"pages/teacher-detail/index",load:function(){var s=p(u().m(function r(n,i){var a;return u().w(function(t){for(;;)switch(t.n){case 0:return t.n=1,h(()=>import("./index.1c9d2416.js"),["./index.1c9d2416.js","./vendors.b2f0d69b.js","../css/vendors.8886af03.css","./common.eb310ac8.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return a=t.v,t.a(2,[a,n,i])}},r)}));function e(r,n){return s.apply(this,arguments)}return e}()},{navigationBarTitleText:"教师详情"}),Object.assign({path:"pages/order-detail/index",load:function(){var s=p(u().m(function r(n,i){var a;return u().w(function(t){for(;;)switch(t.n){case 0:return t.n=1,h(()=>import("./index.25240259.js"),["./index.25240259.js","./vendors.b2f0d69b.js","../css/vendors.8886af03.css","./common.eb310ac8.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return a=t.v,t.a(2,[a,n,i])}},r)}));function e(r,n){return s.apply(this,arguments)}return e}()},{navigationBarTitleText:"订单详情"}),Object.assign({path:"pages/membership/index",load:function(){var s=p(u().m(function r(n,i){var a;return u().w(function(t){for(;;)switch(t.n){case 0:return t.n=1,h(()=>import("./index.404fd5d5.js"),["./index.404fd5d5.js","./vendors.b2f0d69b.js","../css/vendors.8886af03.css","./common.eb310ac8.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return a=t.v,t.a(2,[a,n,i])}},r)}));function e(r,n){return s.apply(this,arguments)}return e}()},{navigationBarTitleText:"会员中心"}),Object.assign({path:"pages/distribution/index",load:function(){var s=p(u().m(function r(n,i){var a;return u().w(function(t){for(;;)switch(t.n){case 0:return t.n=1,h(()=>import("./index.23df7314.js"),["./index.23df7314.js","./vendors.b2f0d69b.js","../css/vendors.8886af03.css","./common.eb310ac8.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return a=t.v,t.a(2,[a,n,i])}},r)}));function e(r,n){return s.apply(this,arguments)}return e}()},{navigationBarTitleText:"分销中心"}),Object.assign({path:"pages/org-dashboard/index",load:function(){var s=p(u().m(function r(n,i){var a;return u().w(function(t){for(;;)switch(t.n){case 0:return t.n=1,h(()=>import("./index.04f9dcb8.js"),["./index.04f9dcb8.js","./vendors.b2f0d69b.js","../css/vendors.8886af03.css","./common.eb310ac8.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return a=t.v,t.a(2,[a,n,i])}},r)}));function e(r,n){return s.apply(this,arguments)}return e}()},{navigationBarTitleText:"机构管理"}),Object.assign({path:"pages/agent-dashboard/index",load:function(){var s=p(u().m(function r(n,i){var a;return u().w(function(t){for(;;)switch(t.n){case 0:return t.n=1,h(()=>import("./index.74cebca7.js"),["./index.74cebca7.js","./vendors.b2f0d69b.js","../css/vendors.8886af03.css","./common.eb310ac8.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return a=t.v,t.a(2,[a,n,i])}},r)}));function e(r,n){return s.apply(this,arguments)}return e}()},{navigationBarTitleText:"代理中心"}),Object.assign({path:"pages/admin/index",load:function(){var s=p(u().m(function r(n,i){var a;return u().w(function(t){for(;;)switch(t.n){case 0:return t.n=1,h(()=>import("./index.3c72fa17.js"),["./index.3c72fa17.js","./vendors.b2f0d69b.js","../css/vendors.8886af03.css","./common.eb310ac8.js","../css/index.9d6364e4.css"],import.meta.url);case 1:return a=t.v,t.a(2,[a,n,i])}},r)}));function e(r,n){return s.apply(this,arguments)}return e}()},{navigationBarTitleText:"管理后台",navigationBarBackgroundColor:"#1e3a5f",navigationBarTextStyle:"white"})];Object.assign(Z,{findDOMNode:A.findDOMNode,render:A.render,unstable_batchedUpdates:A.unstable_batchedUpdates});Fe();var hr=Pe(fr,ee,Z,_),te=ke({window:Q});Ne(_,te);Ae(te,hr,_,ee);De({designWidth:750,deviceRatio:{375:2,640:1.17,750:1,828:.905},baseFontSize:20,unitPrecision:void 0,targetUnit:void 0});
