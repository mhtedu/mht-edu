import{g as pe,E as W,q as ge,s as me,b as v,d as U,v as b,_ as x,j as u,V as d,w as he,H as fe,f as ve,x as L,i as be,S as xe,y as _e,z as we,e as ye,A as Ee,X as Te,B as je,D as Be,F as Ce,G as l,J as s,K as Pe,M as Q,N as Z,r as D,O as Oe,P as Ae,Q as Se,U as Fe,W as De,Y as ke,Z as ee,$ as c}from"./vendors.9a3f5ef0.js";import{c as N,P as Ne,B as P,C as Re,a as Le,b as k,d as Ie,e as He,t as $,T as Ve}from"./common.cc985876.js";(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))n(i);new MutationObserver(i=>{for(const t of i)if(t.type==="childList")for(const e of t.addedNodes)e.tagName==="LINK"&&e.rel==="modulepreload"&&n(e)}).observe(document,{childList:!0,subtree:!0});function r(i){const t={};return i.integrity&&(t.integrity=i.integrity),i.referrerPolicy&&(t.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?t.credentials="include":i.crossOrigin==="anonymous"?t.credentials="omit":t.credentials="same-origin",t}function n(i){if(i.ep)return;i.ep=!0;const t=r(i);fetch(i.href,t)}})();var ze=`
/* H5 端隐藏 TabBar 空图标（只隐藏没有 src 的图标） */
.weui-tabbar__icon:not([src]),
.weui-tabbar__icon[src=''] {
  display: none !important;
}

.weui-tabbar__item:has(.weui-tabbar__icon:not([src])) .weui-tabbar__label,
.weui-tabbar__item:has(.weui-tabbar__icon[src='']) .weui-tabbar__label {
  margin-top: 0 !important;
}

/* Vite 错误覆盖层无法选择文本的问题 */
vite-error-overlay {
  /* stylelint-disable-next-line property-no-vendor-prefix */
  -webkit-user-select: text !important;
}

vite-error-overlay::part(window) {
  max-width: 90vw;
  padding: 10px;
}

.taro_page {
  overflow: auto;
}

::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}

::-webkit-scrollbar-track {
  background: transparent;
}

::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.2);
  border-radius: 2px;
}

::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.3);
}

/* H5 导航栏页面自动添加顶部间距 */
body.h5-navbar-visible .taro_page {
  padding-top: 44px;
}

body.h5-navbar-visible .toaster[data-position^="top"] {
  top: 44px !important;
}

/* Sheet 组件在 H5 导航栏下的位置修正 */
body.h5-navbar-visible .sheet-content:not([data-side="bottom"]) {
    top: 44px !important;
}

/*
 * H5 端 rem 适配：与小程序 rpx 缩放一致
 * 375px 屏幕：1rem = 16px，小程序 32rpx = 16px
 */
html {
    font-size: 4vw !important;
}

/* H5 端组件默认样式修复 */
taro-view-core {
    display: block;
}

taro-text-core {
    display: inline;
}

taro-input-core {
    display: block;
    width: 100%;
}

taro-input-core input {
    width: 100%;
    background: transparent;
    border: none;
    outline: none;
}

taro-input-core.taro-otp-hidden-input input {
    color: transparent;
    caret-color: transparent;
    -webkit-text-fill-color: transparent;
}

/* 全局按钮样式重置 */
taro-button-core,
button {
    margin: 0 !important;
    padding: 0 !important;
    line-height: inherit;
    display: flex;
    align-items: center;
    justify-content: center;
}

taro-button-core::after,
button::after {
    border: none;
}

taro-textarea-core > textarea,
.taro-textarea,
textarea.taro-textarea {
    resize: none !important;
}
`,Me=`
/* PC 宽屏适配 - 基础布局 */
@media (min-width: 769px) {
  html {
    font-size: 15px !important;
  }

  body {
    background-color: #f3f4f6 !important;
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    min-height: 100vh !important;
  }
}
`,We=`
/* PC 宽屏适配 - 手机框样式（有 TabBar 页面） */
@media (min-width: 769px) {
  .taro-tabbar__container {
    width: 375px !important;
    max-width: 375px !important;
    height: calc(100vh - 40px) !important;
    max-height: 900px !important;
    background-color: #fff !important;
    transform: translateX(0) !important;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1) !important;
    border-radius: 20px !important;
    overflow: hidden !important;
    position: relative !important;
  }

  .taro-tabbar__panel {
    height: 100% !important;
    overflow: auto !important;
  }
}

/* PC 宽屏适配 - Toast 定位到手机框范围内 */
@media (min-width: 769px) {
  body .toaster {
    left: 50% !important;
    right: auto !important;
    width: 375px !important;
    max-width: 375px !important;
    transform: translateX(-50%) !important;
    box-sizing: border-box !important;
  }
}

/* PC 宽屏适配 - 手机框样式（无 TabBar 页面，通过 JS 添加 no-tabbar 类） */
@media (min-width: 769px) {
  body.no-tabbar #app {
    width: 375px !important;
    max-width: 375px !important;
    height: calc(100vh - 40px) !important;
    max-height: 900px !important;
    background-color: #fff !important;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1) !important;
    border-radius: 20px !important;
    overflow: hidden !important;
    position: relative !important;
    transform: translateX(0) !important;
  }

  body.no-tabbar #app .taro_router {
    height: 100% !important;
    overflow: auto !important;
  }
}
`;function Ue(){var o=document.createElement("style");o.innerHTML=ze+Me+We,document.head.appendChild(o)}function $e(){var o=function(){var n=!!document.querySelector(".taro-tabbar__container");document.body.classList.toggle("no-tabbar",!n)};o();var a=new MutationObserver(o);a.observe(document.body,{childList:!0,subtree:!0})}function Ye(){Ue(),$e()}function qe(){var o=pe();if(o===W.WEAPP||o===W.TT)try{var a=ge(),r=a.miniProgram.envVersion;console.log("[Debug] envVersion:",r),r!=="release"&&me({enableDebug:!0})}catch(n){console.error("[Debug] 开启调试模式失败:",n)}}var Xe={visible:!1,title:"",bgColor:"#ffffff",textStyle:"black",navStyle:"default",transparent:"none",leftIcon:"none"},Ge=function(){var a,r=L();return(r==null||(a=r.config)===null||a===void 0?void 0:a.window)||{}},Je=function(){var a,r,n=(a=L())===null||a===void 0||(a=a.config)===null||a===void 0?void 0:a.tabBar;return new Set((n==null||(r=n.list)===null||r===void 0?void 0:r.map(function(i){return i.pagePath}))||[])},Y=function(){var a,r=L();return(r==null||(a=r.config)===null||a===void 0||(a=a.pages)===null||a===void 0?void 0:a[0])||"pages/index/index"},A=function(a){return a.replace(/^\//,"")},Ke=function(a,r,n,i){if(!a)return"none";var t=A(a),e=A(i),f=t===e,p=r.has(t)||r.has("/".concat(t)),m=n>1;return p||f?"none":m?"back":"home"},Qe=function(){var a=v.useState(Xe),r=U(a,2),n=r[0],i=r[1],t=v.useState(0),e=U(t,2),f=e[0],p=e[1],m=v.useCallback(function(){var g=b.getCurrentPages();if(g.length===0){i(function(de){return x(x({},de),{},{visible:!1})});return}var h=g[g.length-1],V=(h==null?void 0:h.route)||"";if(V){var _=(h==null?void 0:h.config)||{},w=Ge(),B=Je(),ue=Y(),C=A(V),z=A(ue),le=C===z,ce=B.has(C)||B.has("/".concat(C)),M=B.size<=1&&g.length<=1&&(le||ce);i({visible:!M,title:document.title||_.navigationBarTitleText||w.navigationBarTitleText||"",bgColor:_.navigationBarBackgroundColor||w.navigationBarBackgroundColor||"#ffffff",textStyle:_.navigationBarTextStyle||w.navigationBarTextStyle||"black",navStyle:_.navigationStyle||w.navigationStyle||"default",transparent:_.transparentTitle||w.transparentTitle||"none",leftIcon:M?"none":Ke(C,B,g.length,z)})}},[]);b.useDidShow(function(){m()}),b.usePageScroll(function(g){var h=g.scrollTop;n.transparent==="auto"&&p(Math.min(h/100,1))}),v.useEffect(function(){var g=null,h=new MutationObserver(function(){g&&clearTimeout(g),g=setTimeout(function(){m()},50)});return h.observe(document.head,{subtree:!0,childList:!0,characterData:!0}),m(),function(){h.disconnect(),g&&clearTimeout(g)}},[m]);var F=n.visible&&n.navStyle!=="custom";if(v.useEffect(function(){F?document.body.classList.add("h5-navbar-visible"):document.body.classList.remove("h5-navbar-visible")},[F]),!F)return u.jsx(u.Fragment,{});var H=n.textStyle==="white"?"#fff":"#333",te=n.textStyle==="white"?"text-white":"text-gray-800",ie=function(){return n.transparent==="always"?{backgroundColor:"transparent"}:n.transparent==="auto"?{backgroundColor:n.bgColor,opacity:f}:{backgroundColor:n.bgColor}},oe=function(){return b.navigateBack()},se=function(){var h=Y();b.reLaunch({url:"/".concat(h)})};return u.jsxs(u.Fragment,{children:[u.jsxs(d,{className:"fixed top-0 left-0 right-0 h-11 flex items-center justify-center z-1000",style:ie(),children:[n.leftIcon==="back"&&u.jsx(d,{className:"absolute left-2 top-1/2 -translate-y-1/2 p-1 flex items-center justify-center",onClick:oe,children:u.jsx(he,{size:24,color:H})}),n.leftIcon==="home"&&u.jsx(d,{className:"absolute left-2 top-1/2 -translate-y-1/2 p-1 flex items-center justify-center",onClick:se,children:u.jsx(fe,{size:22,color:H})}),u.jsx(ve,{className:"text-base font-medium max-w-3/5 truncate ".concat(te),children:n.title})]}),u.jsx(d,{className:"h-11 shrink-0"})]})},Ze=function(a){var r=a.children;return u.jsxs(u.Fragment,{children:[u.jsx(Qe,{}),r]})},er=["className","children","orientation"],re=v.forwardRef(function(o,a){var r=o.className,n=o.children,i=o.orientation,t=i===void 0?"vertical":i,e=be(o,er),f=t==="horizontal"||t==="both",p=t==="vertical"||t==="both";return u.jsx(xe,x(x({ref:a,className:N("relative",r),scrollY:p,scrollX:f,style:{overflowX:f?"auto":"hidden",overflowY:p?"auto":"hidden"}},e),{},{children:n}))});re.displayName="ScrollArea";var rr={error:null,report:"",source:"",visible:!1,open:!1,timestamp:""},q="hsl(360, 100%, 45%)",X=!1,S=rr,R=new Set,nr=function(){R.forEach(function(a){return a()})},ar=function(a){return R.add(a),function(){return R.delete(a)}},G=function(){return S},ne=function(a){S=a,nr()},tr=function(){var o=l(s().m(function a(r){var n,i,t,e,f;return s().w(function(p){for(;;)switch(p.p=p.n){case 0:if(typeof window!="undefined"){p.n=1;break}return p.a(2,!1);case 1:if(p.p=1,!((n=navigator.clipboard)!==null&&n!==void 0&&n.writeText)){p.n=3;break}return p.n=2,navigator.clipboard.writeText(r);case 2:return p.a(2,!0);case 3:p.n=5;break;case 4:p.p=4,e=p.v,console.warn("[H5ErrorBoundary] Clipboard API copy failed:",e);case 5:return p.p=5,i=document.createElement("textarea"),i.value=r,i.setAttribute("readonly","true"),i.style.position="fixed",i.style.opacity="0",document.body.appendChild(i),i.select(),t=document.execCommand("copy"),document.body.removeChild(i),p.a(2,t);case 6:return p.p=6,f=p.v,console.warn("[H5ErrorBoundary] Fallback copy failed:",f),p.a(2,!1)}},a,null,[[5,6],[1,4]])}));return function(r){return o.apply(this,arguments)}}(),ir=function(a){if(a instanceof Error)return a;if(typeof a=="string")return new Error(a);try{return new Error(JSON.stringify(a))}catch(r){return new Error(String(a))}},or=function(a){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n=["[H5 Runtime Error]","Time: ".concat(new Date().toISOString()),r.source?"Source: ".concat(r.source):"","Name: ".concat(a.name),"Message: ".concat(a.message),a.stack?`Stack:
`.concat(a.stack):"",r.componentStack?`Component Stack:
`.concat(r.componentStack):"",typeof navigator!="undefined"?"User Agent: ".concat(navigator.userAgent):""].filter(Boolean);return n.join(`

`)},J=function(a){S.visible&&ne(x(x({},S),{},{open:a}))},I=function(a){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};if(typeof window!="undefined"){var n=ir(a),i=or(n,r),t=new Date().toLocaleTimeString("zh-CN",{hour:"2-digit",minute:"2-digit",second:"2-digit"});ne({error:n,report:i,source:r.source||"runtime",timestamp:t,visible:!0,open:!1}),console.error("[H5ErrorOverlay] Showing error overlay:",n,r)}},sr=function(a){var r=a.error||new Error(a.message||"Unknown H5 runtime error");I(r,{source:"window.error"})},ur=function(a){I(a.reason,{source:"window.unhandledrejection"})},lr=function(){typeof window=="undefined"||X||(X=!0,window.addEventListener("error",sr),window.addEventListener("unhandledrejection",ur))},cr=function(){var a,r,n=v.useSyncExternalStore(ar,G,G);if(!n.visible)return null;var i=((a=n.error)===null||a===void 0?void 0:a.name)||"Error";return u.jsx(Ne,{children:u.jsxs(d,{className:"pointer-events-none fixed inset-0 z-[2147483646]",children:[u.jsx(d,{className:"pointer-events-auto fixed bottom-5 left-5",children:u.jsx(P,{variant:"outline",size:"icon",className:N("h-11 w-11 rounded-full shadow-md transition-transform"),style:{backgroundColor:"hsl(359, 100%, 97%)",borderColor:"hsl(359, 100%, 94%)",color:q},onClick:function(){return J(!n.open)},children:u.jsx(ye,{size:22,color:q})})}),n.open&&u.jsx(d,{className:"pointer-events-none fixed inset-0 bg-white bg-opacity-15 supports-[backdrop-filter]:backdrop-blur-md",children:u.jsx(d,{className:"absolute inset-0 flex items-center justify-center px-4 py-4",children:u.jsx(d,{className:"w-full max-w-md",style:{width:"min(calc(100vw - 32px), var(--h5-phone-width, 390px))",height:"min(calc(100vh - 32px), 900px)"},children:u.jsx(Re,{className:N("pointer-events-auto h-full rounded-2xl border border-border bg-background text-foreground shadow-2xl"),children:u.jsxs(d,{className:"relative flex h-full flex-col",children:[u.jsxs(Le,{className:"gap-2 p-4 pb-2",children:[u.jsxs(d,{className:"flex items-start justify-between gap-3",children:[u.jsxs(d,{className:"flex flex-wrap items-center gap-2",children:[u.jsx(k,{variant:"destructive",className:"border-none bg-red-500 px-3 py-1 text-xs font-medium text-white",children:"Runtime Error"}),u.jsx(k,{variant:"outline",className:"px-3 py-1 text-xs",children:n.source})]}),u.jsxs(d,{className:"flex shrink-0 items-center gap-1",children:[u.jsx(P,{variant:"ghost",size:"icon",className:"h-8 w-8 rounded-full",onClick:function(){return window.location.reload()},children:u.jsx(Ee,{size:15,color:"inherit"})}),u.jsx(P,{variant:"ghost",size:"icon",className:"h-8 w-8 rounded-full",onClick:function(){return J(!1)},children:u.jsx(Te,{size:17,color:"inherit"})})]})]}),u.jsxs(d,{className:"flex items-center justify-between gap-3",children:[u.jsx(Ie,{className:"text-left text-lg",children:i}),u.jsxs(P,{variant:"outline",size:"sm",className:"shrink-0 rounded-lg",onClick:function(){var t=l(s().m(function f(){var p;return s().w(function(m){for(;;)switch(m.n){case 0:return m.n=1,tr(n.report);case 1:if(p=m.v,!p){m.n=2;break}return $.success("已复制错误信息",{description:"可发送给 Agent 进行自动修复",position:"top-center"}),m.a(2);case 2:$.warning("复制失败",{description:"请直接选中文本后手动复制。",position:"top-center"});case 3:return m.a(2)}},f)}));function e(){return t.apply(this,arguments)}return e}(),children:[u.jsx(je,{size:15,color:"inherit"}),u.jsx(d,{children:"复制错误"})]})]})]}),u.jsx(He,{className:"min-h-0 flex-1 overflow-hidden px-4 pb-4 pt-2",children:u.jsxs(d,{className:"flex h-full min-h-0 flex-col gap-2",children:[u.jsxs(d,{className:"flex flex-wrap items-center gap-x-4 gap-y-2 rounded-lg border border-border px-3 py-2 text-sm",children:[u.jsxs(d,{className:"flex items-center gap-2",children:[u.jsx(d,{className:"text-muted-foreground",children:"Error"}),u.jsx(d,{className:"font-medium text-foreground",children:((r=n.error)===null||r===void 0?void 0:r.name)||"Error"})]}),u.jsx(d,{className:"h-4 w-px bg-border"}),u.jsxs(d,{className:"flex items-center gap-2",children:[u.jsx(d,{className:"text-muted-foreground",children:"Source"}),u.jsx(d,{className:"font-medium text-foreground",children:n.source})]})]}),u.jsxs(d,{className:"min-h-0 flex flex-1 flex-col overflow-hidden rounded-xl border border-border bg-black text-white",children:[u.jsxs(d,{className:"flex items-center justify-between border-b border-white border-opacity-10 px-3 py-3",children:[u.jsx(d,{className:"text-xs font-medium uppercase tracking-wide text-zinc-400",children:"Full Report"}),u.jsx(k,{variant:"outline",className:"border-zinc-700 bg-transparent px-2 py-1 text-xs text-zinc-400",children:n.timestamp})]}),u.jsx(re,{className:"min-h-0 flex-1 w-full",orientation:"both",children:u.jsx(d,{className:"inline-block min-w-full whitespace-pre px-3 py-3 pb-8 font-mono text-xs leading-6 text-zinc-200",children:n.report})})]})]})})]})})})})})]})})},dr=function(o){function a(){var r;Be(this,a);for(var n=arguments.length,i=new Array(n),t=0;t<n;t++)i[t]=arguments[t];return r=Ce(this,a,[].concat(i)),r.state={error:null},r}return _e(a,o),we(a,[{key:"componentDidUpdate",value:function(n){this.state.error&&n.children!==this.props.children&&this.setState({error:null})}},{key:"componentDidCatch",value:function(n,i){I(n,{source:"React Error Boundary",componentStack:i.componentStack||""})}},{key:"render",value:function(){return u.jsxs(u.Fragment,{children:[u.jsx(cr,{}),this.state.error?null:this.props.children]})}}],[{key:"getDerivedStateFromError",value:function(n){return{error:n}}}])}(v.Component),pr=function(a){var r=a.children;return u.jsx(dr,{children:r})},gr=function(a){var r=a.children;return lr(),b.useLaunch(function(){qe(),Ye()}),u.jsx(pr,{children:u.jsx(Ze,{children:r})})},mr=function(a){var r=a.children;return u.jsxs(Pe,{defaultColor:"#000",defaultSize:24,children:[u.jsx(gr,{children:r}),u.jsx(Ve,{})]})},E=Q.__taroAppConfig={router:{mode:"hash"},pages:["pages/index/index","pages/mall/index","pages/message/index","pages/profile/index","pages/role-switch/index","pages/teacher-workbench/index","pages/share-center/index","pages/publish/index","pages/teacher-detail/index","pages/orders/index","pages/order-detail/index","pages/membership/index","pages/distribution/index","pages/org-dashboard/index","pages/org-teachers/index","pages/org-courses/index","pages/org-invite/index","pages/org-settings/index","pages/agent-dashboard/index","pages/agent-apply/index","pages/admin/index","pages/login/index","pages/product-detail/index","pages/chat/index","pages/course-manage/index","pages/parent-profile/index","pages/activity-detail/index","pages/activities/index","pages/favorites/index","pages/students/index","pages/earnings/index","pages/settings/index"],window:{backgroundTextStyle:"light",navigationBarBackgroundColor:"#fff",navigationBarTitleText:"棉花糖教育",navigationBarTextStyle:"black"},tabBar:{color:"#999999",selectedColor:"#2563EB",backgroundColor:"#ffffff",borderStyle:"black",list:[{pagePath:"pages/index/index",text:"首页",iconPath:"./assets/tabbar/home.png",selectedIconPath:"./assets/tabbar/home-active.png"},{pagePath:"pages/mall/index",text:"商城",iconPath:"./assets/tabbar/shopping-cart.png",selectedIconPath:"./assets/tabbar/shopping-cart-active.png"},{pagePath:"pages/message/index",text:"消息",iconPath:"./assets/tabbar/message-square.png",selectedIconPath:"./assets/tabbar/message-square-active.png"},{pagePath:"pages/profile/index",text:"我的",iconPath:"./assets/tabbar/user.png",selectedIconPath:"./assets/tabbar/user-active.png"}]}},T=[],j=[];T[0]="/static/images/home.png";j[0]="/static/images/home-active.png";T[1]="/static/images/shopping-cart.png";j[1]="/static/images/shopping-cart-active.png";T[2]="/static/images/message-square.png";j[2]="/static/images/message-square-active.png";T[3]="/static/images/user.png";j[3]="/static/images/user-active.png";var K=E.tabBar.list;for(var y=0;y<K.length;y++){var O=K[y];O.iconPath&&(O.iconPath=T[y]),O.selectedIconPath&&(O.selectedIconPath=j[y])}E.routes=[Object.assign({path:"pages/index/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.50ba2d43.js"),["./index.50ba2d43.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.b21ed693.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"首页"}),Object.assign({path:"pages/mall/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.ca5cdfe5.js"),["./index.ca5cdfe5.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.5586a80f.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"教辅商城"}),Object.assign({path:"pages/message/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.4c8db3f7.js"),["./index.4c8db3f7.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"消息"}),Object.assign({path:"pages/profile/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.0ac7b953.js"),["./index.0ac7b953.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"我的"}),Object.assign({path:"pages/role-switch/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.4cf26bae.js"),["./index.4cf26bae.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"角色切换"}),Object.assign({path:"pages/teacher-workbench/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.d5cc27e5.js"),["./index.d5cc27e5.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"教师工作台"}),Object.assign({path:"pages/share-center/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.16f50c13.js"),["./index.16f50c13.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"分享中心"}),Object.assign({path:"pages/publish/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.26aa50f1.js"),["./index.26aa50f1.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"发布需求"}),Object.assign({path:"pages/teacher-detail/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.a6d97d58.js"),["./index.a6d97d58.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.896b538c.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"教师主页"}),Object.assign({path:"pages/orders/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.d16110ec.js"),["./index.d16110ec.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"订单"}),Object.assign({path:"pages/order-detail/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.1ce28c68.js"),["./index.1ce28c68.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"订单详情"}),Object.assign({path:"pages/membership/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.7a55f33f.js"),["./index.7a55f33f.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"会员中心"}),Object.assign({path:"pages/distribution/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.3b409328.js"),["./index.3b409328.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"分销中心"}),Object.assign({path:"pages/org-dashboard/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.b4135507.js"),["./index.b4135507.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"机构管理"}),Object.assign({path:"pages/org-teachers/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.9dcca55e.js"),["./index.9dcca55e.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.4c5f4685.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"教师管理"}),Object.assign({path:"pages/org-courses/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.15c7c221.js"),["./index.15c7c221.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.5a1d135c.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"课程管理"}),Object.assign({path:"pages/org-invite/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.63448c24.js"),["./index.63448c24.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.fb83eb84.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"邀请教师"}),Object.assign({path:"pages/org-settings/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.34814c66.js"),["./index.34814c66.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.47e6bce5.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"机构设置"}),Object.assign({path:"pages/agent-dashboard/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.b6c49f4b.js"),["./index.b6c49f4b.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"代理中心"}),Object.assign({path:"pages/agent-apply/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.00f8bc58.js"),["./index.00f8bc58.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"申请代理"}),Object.assign({path:"pages/admin/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.232b25f5.js"),["./index.232b25f5.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.9d6364e4.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"管理后台",navigationBarBackgroundColor:"#1e3a5f",navigationBarTextStyle:"white"}),Object.assign({path:"pages/login/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.1e007f0f.js"),["./index.1e007f0f.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.8b4d49f5.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"登录",navigationBarBackgroundColor:"#2563EB",navigationBarTextStyle:"white"}),Object.assign({path:"pages/product-detail/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.e62d59cc.js"),["./index.e62d59cc.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.e3b0c442.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"商品详情"}),Object.assign({path:"pages/chat/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.0e04cbb9.js"),["./index.0e04cbb9.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js","../css/index.9949c93c.css"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"聊天"}),Object.assign({path:"pages/course-manage/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.12958fac.js"),["./index.12958fac.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"课时管理"}),Object.assign({path:"pages/parent-profile/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.466771f1.js"),["./index.466771f1.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"家长主页"}),Object.assign({path:"pages/activity-detail/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.fd77ec25.js"),["./index.fd77ec25.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"活动详情"}),Object.assign({path:"pages/activities/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.126c012d.js"),["./index.126c012d.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"活动中心"}),Object.assign({path:"pages/favorites/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.9b87a490.js"),["./index.9b87a490.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"我的收藏"}),Object.assign({path:"pages/students/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.1ddfc992.js"),["./index.1ddfc992.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"我的学员"}),Object.assign({path:"pages/earnings/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.c1b21eea.js"),["./index.c1b21eea.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"收益中心"}),Object.assign({path:"pages/settings/index",load:function(){var o=l(s().m(function r(n,i){var t;return s().w(function(e){for(;;)switch(e.n){case 0:return e.n=1,c(()=>import("./index.8598fddc.js"),["./index.8598fddc.js","./vendors.9a3f5ef0.js","../css/vendors.8886af03.css","./common.cc985876.js"],import.meta.url);case 1:return t=e.v,e.a(2,[t,n,i])}},r)}));function a(r,n){return o.apply(this,arguments)}return a}()},{navigationBarTitleText:"设置"})];Object.assign(Z,{findDOMNode:D.findDOMNode,render:D.render,unstable_batchedUpdates:D.unstable_batchedUpdates});Oe();var hr=Ae(mr,ee,Z,E),ae=Se({window:Q});Fe(E,ae);De(ae,hr,E,ee);ke({designWidth:750,deviceRatio:{375:2,640:1.17,750:1,828:.905},baseFontSize:20,unitPrecision:void 0,targetUnit:void 0});
